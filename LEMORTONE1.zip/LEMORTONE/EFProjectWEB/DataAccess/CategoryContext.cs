﻿using EFProjectWEB.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;


namespace EFProjectWEB.DataAccess
{
    public class CategoryContext : IdentityDbContext<User>
    {
        public CategoryContext(DbContextOptions<CategoryContext> options) : base(options) { Database.EnsureCreated(); }
        public DbSet<Review> Reviews { get; set; }
        public DbSet<Description> Descriptions { get; set; }
        public DbSet<ColorProduct> colorProducts { get; set; }
        
        public DbSet<OrderDetail> OrderDetails { get; set; }
        public DbSet<CompletedOrder> completedOrders { get; set; }
        public DbSet<CompletedOrderDetail> CompletedOrderDetails { get; set; }
      
        public DbSet<Characteristic>Characteristics { get; set; }
        public DbSet<Product> Product { get; set; }
        public DbSet<ShopCartLine> ShopCartLines { get; set; }
        public DbSet<Images> Images { get; set; }
        public DbSet<Color> Colors { get; set; }
        public DbSet<Orders> Orders { get; set; }
        public DbSet<Category> Categories { get; set; }


    }
}
