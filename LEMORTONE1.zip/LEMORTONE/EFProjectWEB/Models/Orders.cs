﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace EFProjectWEB.Models
{
    public class Orders
    {
        [BindNever]
        public int Id { get; set; }

        
        [MaxLength(50)]
        [Display(Name = "Введіть ім'я:")]
        [Required(ErrorMessage = "Введіть правильне значення!")]
        public string FirstName { get; set; }

        
        [MaxLength(50)]
        [Display(Name = "Введіть прізвище:")]
        [Required(ErrorMessage = "Введіть правильне значення!")]
        public string LastName { get; set; }

        [ScaffoldColumn(false)]
        public DateTime Date { get; set; }

        
        [MaxLength(14)]
        [DataType(DataType.PhoneNumber)]
        [Display(Name = "Введіть номер телефону:")]
        [Required(ErrorMessage = "Введіть правильне значення!")]
        public string PhoneNumber { get; set; }



    }
}
