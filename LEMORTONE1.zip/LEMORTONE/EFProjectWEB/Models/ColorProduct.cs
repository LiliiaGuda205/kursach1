﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace EFProjectWEB.Models
{
    public class ColorProduct
    {
        [Key]
        public int Id { get; set; }
        public int ProductId { get; set; }
        [MaxLength(64)]
        public string ColorId { get; set; }


    }
}
