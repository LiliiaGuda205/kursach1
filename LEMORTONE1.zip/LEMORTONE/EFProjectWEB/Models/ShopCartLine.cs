﻿using EFProjectWEB.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace EFProjectWEB.Models
{
    public class ShopCartLine
    {
        public int Id { get; set; }
        public Product product { get; set; }
        [MaxLength(200)]
        public string shopCartLineID { get; set; }

        public int Kilkist { get; set; }
        public double TotalPrice { get; set; }


        
    }
}
