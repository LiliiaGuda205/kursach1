﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text;

namespace EFProjectWEB.Models
{
    [Serializable]
    public class Product
    {
        [Key]
        public int  ProductId { get; set; }
        
        [MaxLength(128)]
        public string ProductName { get; set; }
        
        public int CategoryId { get; set; }
        public double ProdPrice { get; set; }
        public List<Images> Img { get; set; }
        public List<ColorProduct>Colors { get; set; }
        public Description Description { get; set; }
  
        public Product()
        {
            Colors = new List<ColorProduct>();
            Img = new List<Images>();
        }


    }
}
