﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EFProjectWEB.Models
{
    public class Color
    {
        //Цвет в ргб 
        [Key]
        [MaxLength(20)]
        public string ColorId { get; set; }
        // Название цвета 
        [MaxLength(64)]
        public string ColorName { get; set; }
        
    }
}
