﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EFProjectWEB.Models
{
    public class User : IdentityUser
    {
    }
}
