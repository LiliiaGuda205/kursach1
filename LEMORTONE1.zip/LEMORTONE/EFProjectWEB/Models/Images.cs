﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EFProjectWEB.Models
{
    public class Images
    { 
        [Key]
        [MaxLength(256)]
        public string PathID { get; set; }
        public int ProductId { get; set; }
    }
}
