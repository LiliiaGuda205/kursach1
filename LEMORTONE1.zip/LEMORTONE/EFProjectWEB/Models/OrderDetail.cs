﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace EFProjectWEB.Models
{
    public class OrderDetail
    {
        [Key]
        public int Id { get; set; }
        public int OrderId { get; set; }
        public int ProductId { get; set; }
        public double price { get; set; }
        public int Kilkist { get; set; }
        [MaxLength(64)]
        public string productName { get; set; }
    }
}
