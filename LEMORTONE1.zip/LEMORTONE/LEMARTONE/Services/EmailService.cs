﻿using MimeKit;
using MailKit.Net.Smtp;
using System.Threading.Tasks;
using System;
using System.Collections.Generic;

namespace LEMARTONE.Services
{
    public class EmailService
    {
        public void SendEmailCustom(string email)
        {
            try
            {
                MimeMessage message = new MimeMessage();
                message.From.Add(new MailboxAddress("Lemartone co.", "Пошта"));
                message.To.Add(new MailboxAddress("Пошта куди відправляти"));
                message.Subject = "Магазин"; 
                message.Body = new BodyBuilder() { HtmlBody = "<div style=\"color: green;\">Прийшло нове замовлення </div>" + email }.ToMessageBody(); 

                using (SmtpClient client = new SmtpClient())
                {
                    client.Connect("smtp.gmail.com", 465, true); //або використовуємо порт 465 587
                    client.Authenticate("Пошта", "Пароль"); //логін-пароль від облікового запису
                    client.Send(message);

                    client.Disconnect(true);
                   
                }
            }
            catch (Exception e)
            {
               
            }
        }
        public async Task SendEmailAsync(string email, string subject, string message)
        {
            var emailMessage = new MimeMessage();

            emailMessage.From.Add(new MailboxAddress("Адміністрація сайту", "Email"));
            emailMessage.To.Add(new MailboxAddress("Some", email));
            emailMessage.Subject = subject;
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = message
            };

            using (SmtpClient client = new SmtpClient())
            {
                //порт 587 чи 465
                await client.ConnectAsync("smtp.gmail.com", 587, true);
                await client.AuthenticateAsync("Email", "pass");
                await client.SendAsync(emailMessage);

                await client.DisconnectAsync(true);
            }
        }
    }
}
