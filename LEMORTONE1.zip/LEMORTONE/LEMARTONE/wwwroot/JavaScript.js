﻿$(window).scroll(function () {
    var hat = document.getElementById("homeHat");
    var hatLogo = document.getElementById("homeHatLogo");
    //console.log(window.scrollY);
    var opacity = 0;
    if (window.scrollY > 310) {
        opacity = 1;
    }
    else if (window.scrollY > 280) {
        opacity = 0.95;
    }
    else if (window.scrollY > 250) {
        opacity = 0.85;
    }
    else if (window.scrollY > 220) {
        opacity = 0.75;
    }
    else if (window.scrollY > 190) {
        opacity = 0.65;
    }
    else if (window.scrollY > 160) {
        opacity = 0.55;
    }
    else if (window.pageYOffset > 130) {
        opacity = 0.45;
    }
    else if (window.pageYOffset > 100) {
        opacity = 0.35;
    }
    else if (window.pageYOffset > 70) {
        opacity = 0.25;
    }
    else if (window.pageYOffset > 40) {
        opacity = 0.1;
    }
    else if (window.pageYOffset > 10) {
        opacity = 0.05;
    }
    hat.style.backgroundColor = "rgba(255,255,255," + opacity + ")";
    hatLogo.style.opacity = opacity;
});
(function () {
	'use strict';

	var thumbs = document.querySelectorAll('.thumbs img'),
		image = document.querySelector('.photo-box img'),
		count = thumbs.length,
		current = 0;

	// управление кликами по превью фото
	[].forEach.call(thumbs, function (thumb, n) {
		thumb.index = n;
	});

})();
function myFunction(imgaaaaaas) {
	var expandImg = document.getElementById("expandedImg");
	expandImg.src = imgaaaaaas.src;

}

function plus(el) {
	el.Kilkist += 1;
	var quant = document.querySelector('.quantity');
	quant.innerHTML = "121";
}

function openbox(id) {

	display = document.getElementById(id).style.display;



    if (display == 'none') {

        document.getElementById(id).style.display = 'block';
    }
	else {

		document.getElementById(id).style.display = 'none';

	}

}

function showText(name) {
	var text = document.getElementById(name);
	if (text.style.display == 'block') {
		text.style.display = "none";
	}
	else {
		text.style.display = "block";
	}

}

function chooseColor(labelId) {
    var element = document.getElementById(labelId);
    if (element.style.border != "1px solid grey") {
        element.style.border = "1px solid grey";
    }
    else {
        element.style.border = "1px solid grey";
    }
    
}


var filterSortItems = document.getElementsByClassName('showSortButt');
for (let i = 0; i < filterSortItems.length; i++)
{
    filterSortItems[i].oninput = function () {
        document.getElementById('sendFilterButt').style.display = 'block';
    }
}