﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.Models;

namespace LEMARTONE.ViewModels
{
    public class AdminDoneOrdersViewModel
    {
        public CompletedOrder comporder { get; set; }
        public List<CompletedOrderDetail> comporderDetails { get; set; }
        public string summ { get; set; }
        public List<string> ProductNames { get; set; }
    }
}
