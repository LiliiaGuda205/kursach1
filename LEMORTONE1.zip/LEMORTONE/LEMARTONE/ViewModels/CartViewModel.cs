﻿using EFProjectWEB.Models;
using LEMARTONE.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class CartViewModel
    {
        public List<ShopCartLine> ShopCart {get;set;}
        public List<string>Images { get; set; }
        public List<int> quantities { get; set; }
    }
}
