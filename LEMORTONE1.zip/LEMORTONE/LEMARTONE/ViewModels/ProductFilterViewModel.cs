﻿using EFProjectWEB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class ProductFilterViewModel
    {
        public int categoryNum { get; set; }
        public int minVolume { get; set; }
        public int maxVolume { get; set; }
        public int minPrice { get; set; }
        public int maxPrice { get; set; }
        public int sortNum { get; set; }
        public List<Product> filteredProducts { get; set; }
        public ProductFilterViewModel()
        {
            filteredProducts = new List<Product>();
        }
    }
}
