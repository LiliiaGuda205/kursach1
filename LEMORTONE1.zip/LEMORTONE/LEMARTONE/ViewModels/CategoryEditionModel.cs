﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class CategoryEditionModel
    {
        public string CatName { get; set; }
        public int CatId { get; set; }
        public IFormFile Img { get; set; }
        public string ImgPath { get; set; }

    }
}
