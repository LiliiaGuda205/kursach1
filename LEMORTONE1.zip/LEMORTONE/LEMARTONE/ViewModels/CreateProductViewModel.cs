﻿using EFProjectWEB.Models;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class CreateProductViewModel
    {
        public Product product { get; set; }
        public List<string> colors { get; set; }
        public IFormFileCollection formFiles { get; set; }
        public Description Description { get; set; }
        public CreateProductViewModel()
        {
            Description = new Description();
            colors = new List<string>();
        }
    }
}
