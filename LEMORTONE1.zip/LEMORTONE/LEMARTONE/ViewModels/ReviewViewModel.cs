﻿using EFProjectWEB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class ReviewViewModel
    {
        public int reviewProdId { get; set; }
        public List<Review> reviews { get; set; }
        public Review newReview { get; set; }
    }
}
