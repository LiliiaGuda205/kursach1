﻿using EFProjectWEB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class ProductViewModel
    {
        public Product product { get; set; }
        public List<string> Colors { get; set; }
        public List<string> Imgages { get; set; }
        public List<Review> Reviews { get; set; }
        public List<Product> SameCategoryProds { get; set; }
        public Description description { get; set; }
        public ProductViewModel()
        {
            SameCategoryProds = new List<Product>();
            Colors = new List<string>();
            Imgages = new List<string>();
            Reviews = new List<Review>();
        }
    }
}
