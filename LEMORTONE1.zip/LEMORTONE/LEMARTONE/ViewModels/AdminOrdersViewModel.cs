﻿using EFProjectWEB.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LEMARTONE.ViewModels
{
    public class AdminOrdersViewModel
    {
        public Orders order { get; set; }
        public List<OrderDetail> orderDetails { get; set; }
        public string summ { get; set; }
        public List<string> ProductNames { get; set; }
    }
}
