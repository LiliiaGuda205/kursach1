﻿    using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.Models;
using EFProjectWEB.DataAccess;

namespace LEMARTONE.Models
{
    public class ShopCart
    {
        private readonly CategoryContext categoryContext;
        public ShopCart(CategoryContext context)
        {
            categoryContext = context;
        }
        public string shopCartLineID { get; set; }

        public List<ShopCartLine> shopCartLines { get; set; }
        public static ShopCart GetCart(IServiceProvider service)
        {
            ISession session = service.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Session;
            var cookie = service.GetRequiredService<IHttpContextAccessor>()?.HttpContext.Request.Cookies;
            var context = service.GetService<CategoryContext>();
            string shopCartLineId;
            if (cookie.ContainsKey("Cart"))
            {
                shopCartLineId = cookie["Cart"];
            }
            else
                shopCartLineId = session.GetString("CartId") ?? Guid.NewGuid().ToString();



            return new ShopCart(context) { shopCartLineID = shopCartLineId };
        }


        public void AddToCart(Product product, string cookie)
        {
            List<ShopCartLine> cart = (from p in categoryContext.ShopCartLines
                                       where cookie == p.shopCartLineID
                                       where p.product.ProductId == product.ProductId
                                       select p).ToList();
            if (cart.Count == 0)
                categoryContext.ShopCartLines.Add(new ShopCartLine()
                {
                    shopCartLineID = shopCartLineID,
                    product = product,
                    Kilkist = 1,
                    TotalPrice = product.ProdPrice
                });
            else
            {
                cart[0].Kilkist += 1;
                cart[0].TotalPrice = (cart[0].Kilkist * cart[0].product.ProdPrice);

                categoryContext.ShopCartLines.Update(cart[0]);
            }
            categoryContext.SaveChanges();

        }
        public string GetShopCartLinesID()
        {
            return shopCartLineID;


        }
        public List<ShopCartLine> GetShopCartLines()
        {
            return categoryContext.ShopCartLines.Where(c => c.shopCartLineID == shopCartLineID).Include(s => s.product).ToList();
        }


        //public void DeleteShopCart()
        //{
        //    categoryContext.ShopCartLines;
        //}
    }
}
