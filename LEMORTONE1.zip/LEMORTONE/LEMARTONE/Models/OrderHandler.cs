﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.Models;
using EFProjectWEB.DataAccess;
using LEMARTONE.Interfaces;
using LEMARTONE.Services;

namespace LEMARTONE.Models
{
    public class OrderHandler: IAllOrders
    {
        private readonly CategoryContext categoryContext;
        private readonly ShopCart shopCart;
        private readonly EmailService email;
        public OrderHandler(CategoryContext categoryContext, ShopCart shopCart, EmailService email)
        {
            this.email = email;
            this.shopCart = shopCart;
            this.categoryContext = categoryContext;
        }

        public void CreateOrder(Orders orders)
        {

            orders.Date = DateTime.Now;
            categoryContext.Orders.Add(orders);
            //var id = orders.Id;
            var count = categoryContext.Orders.ToList().Count();
            var list = shopCart.GetShopCartLines();
            int id;
            if (categoryContext.Orders.ToList().Count() == 0)
            {
                id = 1;
            }
            else
            {
                id = ((from order in categoryContext.Orders.ToList()
                       select order.Id).Last()) + 1;
            }

            string emailInfo = "<div> " + " ФІО " + orders.FirstName + " " + orders.LastName + " Номер телефона: " + orders.PhoneNumber +  " Дата замовлення:" + orders.Date + "</div> ";
            foreach (var el in list)
            {
                var orderDetail = new OrderDetail()
                {
                    ProductId = el.product.ProductId,
                    OrderId = id,
                    Kilkist = el.Kilkist,
                    price = el.TotalPrice,
                    productName = el.product.ProductName

                };
                emailInfo += "<div> Назва товару:" + el.product.ProductName.ToString() + " Номер товару: " + el.product.ProductId.ToString() + " Кількість товару: " + el.Kilkist.ToString() + " Сумарна вартість:  " + el.TotalPrice.ToString() + "</div>";

                categoryContext.OrderDetails.Add(orderDetail);
            }
            //email.SendEmailCustom(emailInfo);
            categoryContext.SaveChanges();
        }
    }
}
