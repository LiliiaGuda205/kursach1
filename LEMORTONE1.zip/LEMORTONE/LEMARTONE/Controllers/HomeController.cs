﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


using Microsoft.AspNetCore.Mvc;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using Microsoft.AspNetCore.Identity;
using LEMARTONE.Models;
using Microsoft.AspNetCore.Http;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LEMARTONE.Controllers
{

    public class HomeController : Controller
    {
        private readonly  ShopCart _shopCart;
        private CategoryContext db;
        public HomeController(CategoryContext context, ShopCart shopCart)
        {
            _shopCart = shopCart;
            db = context;
        }

        public IActionResult Index()
        {
            List<Category> categories = db.Categories.ToList<Category>();
            if (!HttpContext.Request.Cookies.ContainsKey("Cart"))
            {
                DateTime date = DateTime.Now.AddDays(15);
                var cookieOptions = new CookieOptions
                {

                    Secure = true,

                    HttpOnly = true,

                    Expires = date
                };
                HttpContext.Response.Cookies.Append("Cart", _shopCart.GetShopCartLinesID(), cookieOptions);
                _shopCart.shopCartLineID = HttpContext.Request.Cookies["Cart"];
            }
            else
            {
                _shopCart.shopCartLineID = HttpContext.Request.Cookies["Cart"];
            }
         

            return View(categories);
        }
    }
}
