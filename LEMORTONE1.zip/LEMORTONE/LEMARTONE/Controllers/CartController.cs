﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using LEMARTONE.Models;
using LEMARTONE.ViewModels;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using Microsoft.AspNetCore.Http;

namespace LEMARTONE.Controllers
{
    public class CartController : Controller
    {
        private readonly ShopCart _shopCart;
        private CategoryContext db;
        public CartController(CategoryContext context, ShopCart shopCart)
        {
            db = context;
            _shopCart = shopCart;
        }
        public IActionResult Index()
        {
            List<string> imgs = new List<string>();

            var items = _shopCart.GetShopCartLines();

            if (items.Count > 0)
            {
                foreach (var p in items)
                {
                    imgs.Add((from im in db.Images
                              where im.ProductId == p.product.ProductId
                              select im.PathID).First());
                }


                var obj = new CartViewModel() { ShopCart = items, Images = imgs };

                return View(obj);
            }
            return RedirectToAction("EmptyIndex");
        }
        public ViewResult EmptyIndex()
        {
            return View();
        }

        public RedirectToActionResult addToCart(int id)
        {
            List<Product> products = db.Product.ToList<Product>();
            var item = products.FirstOrDefault(i => i.ProductId == id);
            if (item != null)
            {
                _shopCart.AddToCart(item, HttpContext.Request.Cookies["Cart"]);
            }

            return RedirectToAction("Index");
        }

        [HttpPost]
        public RedirectToActionResult quantityChange(CartViewModel cartViewModel)
        {
            //получаю список щопкартлайнов из бд
            string id = _shopCart.shopCartLineID;
            List<ShopCartLine> shopCartLines = (from sho in db.ShopCartLines
                                                where sho.shopCartLineID == id
                                                select sho).ToList();


            //изменяю
            for (int i =0; i< shopCartLines.Count(); i++)
            {
                shopCartLines[i].Kilkist = cartViewModel.quantities[i];
            }

            foreach (var some in shopCartLines)
                db.ShopCartLines.Update(some);
            //db.ShopCartLines.UpdateRange(shopCartLines);

            db.SaveChanges();
            return RedirectToAction("Index");
        }
        public RedirectToActionResult delete(int id)
        {
            db.ShopCartLines.Remove((from scl in db.ShopCartLines
                                    where scl.Id == id
                                    select scl).First());
            db.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}