﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.Models;
using LEMARTONE.Interfaces;
using LEMARTONE.Services;

namespace LEMARTONE.Controllers
{
    public class OrderController : Controller
    {
        private readonly IAllOrders AllOrders;
        private readonly ShopCart shopCart;
        private readonly EmailService email;
        private readonly CategoryContext categoryContext;


        public OrderController(IAllOrders orders, ShopCart shopCart, CategoryContext categoryContext, EmailService email)
        {
            this.email = email;
            this.shopCart = shopCart;
            this.AllOrders = orders;
            this.categoryContext = categoryContext;
        }
        public IActionResult Checkout()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Checkout(Orders orders)
        {
            shopCart.shopCartLines = shopCart.GetShopCartLines();

            if(shopCart.shopCartLines.Count == 0)
            {
                ModelState.AddModelError("","Товарів немає в корзині!");
            }
            if(ModelState.IsValid)
            {
                AllOrders.CreateOrder(orders);
                
                return RedirectToAction("Complete");
            }
            return View(orders);
        }
        
        public IActionResult Complete()
        {
            string sessionId = shopCart.shopCartLineID;
            //categoryContext.ShopCartLines.Remove(s => s.shopCartLineID == sessionId);
            var cart = (from p in categoryContext.ShopCartLines
                        where p.shopCartLineID == sessionId
                        select p).ToList();
           
            
            categoryContext.ShopCartLines.RemoveRange(cart);
            categoryContext.SaveChanges();
            ViewBag.Massage = "Замовлення оброблене!";
            return View();
        }
    }
}