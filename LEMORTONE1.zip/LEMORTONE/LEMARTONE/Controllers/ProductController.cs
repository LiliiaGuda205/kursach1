﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace LEMARTONE.Controllers
{
    public class ProductController : Controller
    {
        private CategoryContext db;
        public ProductController(CategoryContext context)
        {
            db = context;
        }
        public IActionResult ProductPage(int id)
        {
            ProductViewModel productViewModel;

            Product product = (from p in db.Product
                               where p.ProductId == id
                               select p).First();

            List<string> img = (from imgs in db.Images.ToList()
                                where product.ProductId == imgs.ProductId
                                select imgs.PathID).ToList();

            List<string> colors = (from clr in db.colorProducts.ToList()
                                   where clr.ProductId == product.ProductId
                                   select clr.ColorId).ToList();
            List<Review> reviews = (from rv in db.Reviews.ToList()
                                    where rv.ReviewProductId == product.ProductId
                                    select rv).ToList();
            Description  description = (from p in db.Product
                                        where p.ProductId == id
                                        select p.Description).First();
            List<Product> sameCatProds=new List<Product>();
            sameCatProds.Capacity = 8;
            sameCatProds = (from p in db.Product
                            where p.CategoryId == product.CategoryId && p.ProductId!=id
                            select p).ToList();
            foreach (var p in sameCatProds)
            {
                ViewData[p.ProductId.ToString()] = (from im in db.Images.ToList()
                                                    where im.ProductId == p.ProductId
                                                    select im.PathID).First().ToString();

            }

            productViewModel = new ProductViewModel
            {
                product = product,
                Colors = colors,
                Imgages = img,
                Reviews = reviews,
                description = description,
                SameCategoryProds= sameCatProds
            };

            return View(productViewModel);
        }
        [HttpPost]
        public IActionResult ProductPage(Review review)
        {
            Review newReview = new Review
            {
                Id=0,
                ReviewerName = review.ReviewerName,
                ReviewerPhone = review.ReviewerPhone,
                ReviewProductId = review.ReviewProductId,
                ReviewRating = review.ReviewRating,
                ReviewText = review.ReviewText
            };
            db.Reviews.Add(newReview);
            db.SaveChanges();
            return RedirectToAction("ProductPage", new { id = review.ReviewProductId });
        }
    }
}