﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LEMARTONE.Controllers
{
    [Authorize(Roles = "admin")]
    public class ColorCRUDController : Controller
    {
        private CategoryContext db;
        IWebHostEnvironment _appEnvironment;
        public ColorCRUDController(CategoryContext context, IWebHostEnvironment appEnvironment)
        {
            db = context;
            _appEnvironment = appEnvironment;
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> Create(Color color)
        {

            if (color != null)
            {
                db.Colors.Add(color);
                db.SaveChanges();
            }
            return Redirect("~/AdminOrders/Index");
        }
    }
}