﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace LEMARTONE.Controllers
{
    [Authorize(Roles = "admin")]
    public class ProductCRUDController : Controller
    {
        private readonly CategoryContext db;
        IWebHostEnvironment _appEnvironment;
        public ProductCRUDController(CategoryContext context, IWebHostEnvironment appEnvironment)
        {
            db = context;
            _appEnvironment = appEnvironment;
        }
        
        public async Task<IActionResult> Index()
        {
            return View(await db.Product.ToListAsync());
        }

        
        public IActionResult Create()
        {
            /*List<Category>*/
            ViewBag.Categories = new List<Category>(from c in db.Categories
                                              select c).ToList<Category>();
            
            
            return View();
        }

        // GET: CategoryCreate/Create
        [HttpPost]
        public async Task<RedirectToActionResult> Create(CreateProductViewModel productViewModel)
        {
            List<IFormFile> Imgs = new List<IFormFile>();
            foreach (var file in productViewModel.formFiles)
            {
                Imgs.Add(file);
            }


            string category = (from name in db.Categories
                               where productViewModel.product.CategoryId == name.NameId
                               select name.Name).First();

            List<string> paths = new List<string>();
            int iter = 1;
            foreach (var img in Imgs)
            {
                string formt = img.ContentType.ToString();
                char[] MyChar = { 'i', 'm', 'a', 'g', 'e', '/' };
                string format = formt.TrimStart(MyChar);
                paths.Add("imgs/products/" + category + "/" + productViewModel.product.ProductName + "/" + iter.ToString() + "." + format);
                iter++;
            }

            List<Images> images = new List<Images>();

            string derictory = "/imgs/products/" + category + "/" + productViewModel.product.ProductName;
            Directory.CreateDirectory(_appEnvironment.WebRootPath + derictory);

            for (int i = 0; i < Imgs.Count(); i++)
            {

                images.Add(new Images { PathID = paths[i] });
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + "/" + paths[i], FileMode.CreateNew))
                {
                    await Imgs[i].CopyToAsync(fileStream);
                }
            }
            //ADD TO DB DESCRIPTION
            db.Descriptions.Add(productViewModel.Description);
           
            Product product = new Product()
            {
                ProductName = productViewModel.product.ProductName,
                CategoryId = productViewModel.product.CategoryId,
                ProdPrice = productViewModel.product.ProdPrice,
                Img = images,
                Description = productViewModel.Description
            };

             db.Product.Add(product);

            db.SaveChanges();

            //GET PRODUCT ID
            int addedProductId = (from prd in db.Product.ToList()
                                  select prd.ProductId).Last();
            

            ////ADD TO DB COLOR-PRODUCT RELATIONS
            foreach (var color in productViewModel.colors)
            {

                ColorProduct colorProduct = new ColorProduct
                {
                    ProductId = addedProductId,
                    ColorId = (from clr in db.Colors.ToList()
                               where clr.ColorName == color
                               select clr.ColorId).First()
                };
                db.colorProducts.Add(colorProduct);
            }
            //SAVING
            db.SaveChanges();

            return RedirectToAction("Index");
        }


        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Category user = await db.Categories.FirstOrDefaultAsync(p => p.NameId == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }
        // GET: CategoryCreate/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: CategoryCreate/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        [HttpGet]
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                Product user = await db.Product.FirstOrDefaultAsync(p => p.ProductId == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }

        public IActionResult Delete_c(int? id)
        {

            Product product = db.Product.FirstOrDefault(p => p.ProductId == id);
            if (product != null)
            {
                db.Product.Remove(product);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }
        //GET: CategoryCreate/Delete/5

       public ActionResult Delete(int id)
        {
            if (id != null)
            {
                Product product = db.Product.FirstOrDefault(p => p.ProductId == id);
                return View(product);
            }
            return RedirectToAction("Index");

        }


        // POST: CategoryCreate/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {

            Product user =  db.Product.FirstOrDefault(p => p.ProductId == id);
                if (user != null)
                {
                    db.Product.Remove(user);
                     db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
                return NotFound();


        }
    }
}