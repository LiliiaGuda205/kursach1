﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace LEMARTONE.Controllers
{
    public class ReviewController : Controller
    {
        private CategoryContext db;
        public ReviewController(CategoryContext context)
        {
            db = context;
        }
        public IActionResult Index(int id)
        {

            //List<Review> reviews = (from rev in db.Reviews.ToList()
            //                        where rev.ReviewProductId == id
            //                        select rev).ToList();
            //ViewBag.Product = (from prod in db.Product.ToList()
            //                   where prod.Id == id
            //                   select prod.ProductName).FirstOrDefault();
            //ReviewViewModel reviewViewModel = new ReviewViewModel
            //{
            //    reviewProdId = id,
            //    reviews = reviews
            //};
            return View(/*reviewViewModel*/);
        }
        
        [HttpPost]
        public IActionResult addReview(ReviewViewModel review)
        {
            Review newrev = review.newReview;
            db.Reviews.Add(newrev);
            db.SaveChanges();
            return RedirectToAction("Index", new {id = review.newReview.ReviewProductId});
        }
    } 
}