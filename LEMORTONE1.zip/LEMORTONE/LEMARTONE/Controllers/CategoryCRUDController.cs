﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using static System.Net.Mime.MediaTypeNames;

namespace LEMARTONE.Controllers
{
    [Authorize(Roles = "admin")]
    public class CategoryCRUDController : Controller
    {
        private CategoryContext db;
        IWebHostEnvironment _appEnvironment;
        public CategoryCRUDController(CategoryContext context, IWebHostEnvironment appEnvironment)
        {
            db = context;
            _appEnvironment = appEnvironment;
        }
        // GET: CategoryCreate
        public async Task<IActionResult> Index()
        {
            return View(await db.Categories.ToListAsync());
        }

        // GET: CategoryCreate/Details/5
        public IActionResult Create()
        {
            return View();
        }

        // GET: CategoryCreate/Create
        [HttpPost]
        public async Task<IActionResult> Create(CategoryCRUDViewModel categoryViewModel)
        {

            if (categoryViewModel != null)
            {
                // путь к папке Files
                string path = "imgs/categories/" + categoryViewModel.Img.FileName;
                // сохраняем файл в папку Files в каталоге wwwroot
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + "/" + path, FileMode.Create))
                {
                    await categoryViewModel.Img.CopyToAsync(fileStream);
                }
                Category category = new Category() { Img = path, Name = categoryViewModel.CatName.ToString() };
                db.Categories.Add(category);
                db.SaveChanges();
            }
            return RedirectToAction("Index");
        }


        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                Category user = await db.Categories.FirstOrDefaultAsync(p => p.NameId == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }
        public async Task<IActionResult> Edit(int? id)
        {
            if (id != null)
            {
                Category user = await db.Categories.FirstOrDefaultAsync(p => p.NameId == id);
                if (user != null)
                {
                    CategoryEditionModel category = new CategoryEditionModel {
                        CatId =user.NameId,
                        CatName =user.Name,
                        ImgPath=user.Img
                    };

                    return View(category);
                }
                    
            }
            return NotFound();
        }
        [HttpPost]
        public async Task<IActionResult> Edit(CategoryEditionModel category)
        {
            if(category.Img == null)
            {
                Category renewCat = await db.Categories.FirstOrDefaultAsync(p => p.NameId == category.CatId);
                renewCat.Name = category.CatName;
                db.Categories.Update(renewCat);
            }
            else
            {
                
                Category renewCat = await db.Categories.FirstOrDefaultAsync(p => p.NameId == category.CatId);
                
                System.IO.File.Delete("wwwroot/"+renewCat.Img);
                


                string path = "imgs/categories/" + category.Img.FileName;
                using (var fileStream = new FileStream(_appEnvironment.WebRootPath + "/" + path, FileMode.CreateNew))
                {
                    await category.Img.CopyToAsync(fileStream);
                }
                
                renewCat.Name = category.CatName;
                renewCat.Img = path;
                db.Categories.Update(renewCat);

            }
            await db.SaveChangesAsync();
            return RedirectToAction("Index");
        }
        //[HttpGet]
        [ActionName("Delete")]
        public async Task<IActionResult> ConfirmDelete(int? id)
        {
            if (id != null)
            {
                Category user = await db.Categories.FirstOrDefaultAsync(p => p.NameId == id);
                if (user != null)
                    return View(user);
            }
            return NotFound();
        }


        public async Task<IActionResult> Delete_s(int? id)
        {
            if (id != null)
            {
                Category user = await db.Categories.FirstOrDefaultAsync(p => p.NameId == id);
                if (user != null)
                {
                    db.Categories.Remove(user);
                    await db.SaveChangesAsync();
                    return RedirectToAction("Index");
                }
            }
            return NotFound();
        }


    }
}