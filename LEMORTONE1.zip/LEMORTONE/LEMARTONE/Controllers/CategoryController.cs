﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using LEMARTONE.ViewModels;

namespace LEMARTONE.Controllers
{

    public class CategoryController : Controller
    {
        private CategoryContext db;
        public CategoryController(CategoryContext context)
        {
            db = context;
        }

        public IActionResult Index(int number)
        {
            List<Product> filteredListOfProducts = (from p in db.Product
                            where p.CategoryId == number
                            select p).ToList();
            foreach (var p in filteredListOfProducts)
            {
                ViewData[p.ProductId.ToString()] = (from im in db.Images.ToList()
                                                      where im.ProductId == p.ProductId
                                                      select im.PathID).First().ToString();
                
            }

            ViewData["minVolume"] = (from prd in db.Product
                                     select prd.Description.volume).Min();
            
            ViewData["maxVolume"] = (from prd in db.Product
                                     select prd.Description.volume).Max();
            ViewData["minPrice"] = (from prd in db.Product
                                    select prd.ProdPrice).Min();
            ViewData["maxPrice"] = (from prd in db.Product
                                    select prd.ProdPrice).Max();
            ViewData["maxPriceInput"] = ViewData["maxPrice"];
            ViewData["minPriceInput"] = ViewData["minPrice"];
            ViewData["maxVolumeInput"] = ViewData["maxVolume"];
            ViewData["minVolumeInput"] = ViewData["minVolume"];
            //ViewBag.Colors = Products;
            Category category = (from p in db.Categories
                                 where p.NameId == number
                                 select p).First();
            ViewData["name"] = category.Name;
            ViewData["number"] = number;
            
            return View(filteredListOfProducts);


        }

        public IActionResult FilteredIndex(ProductFilterViewModel productFilterViewModel)
        {
            List<Product> filteredListOfProducts = (from p in db.Product
                                                    where p.Description.volume >= productFilterViewModel.minVolume
                                                    && p.Description.volume <= productFilterViewModel.maxVolume
                                                    && p.CategoryId == productFilterViewModel.categoryNum
                                                    select p).ToList();

            filteredListOfProducts = (from p in filteredListOfProducts
                                      where p.ProdPrice >= productFilterViewModel.minPrice
                        && p.ProdPrice <= productFilterViewModel.maxPrice
                                      select p).ToList();

            if (productFilterViewModel.sortNum == 1)
            {
                filteredListOfProducts = (from p in filteredListOfProducts
                                          orderby p.ProdPrice
                                          select p).ToList();
            }
            else if (productFilterViewModel.sortNum == 2)
            {
                filteredListOfProducts = (from p in filteredListOfProducts
                                          orderby p.ProdPrice descending
                                          select p).ToList();
            }
            foreach (var p in filteredListOfProducts)
            {
                ViewData[p.ProductId.ToString()] = (from im in db.Images.ToList()
                                                    where im.ProductId == p.ProductId
                                                    select im.PathID).First().ToString();

            }

            ViewData["maxPriceInput"] = productFilterViewModel.maxPrice;
            ViewData["minPriceInput"] = productFilterViewModel.minPrice;
            ViewData["maxVolumeInput"] = productFilterViewModel.maxVolume;
            ViewData["minVolumeInput"] = productFilterViewModel.minVolume;

            Category category = (from p in db.Categories
                                 where p.NameId == productFilterViewModel.categoryNum
                                 select p).First();
            ViewData["name"] = category.Name;
            ViewData["number"] = productFilterViewModel.categoryNum;
            ViewData["sortNum"] = productFilterViewModel.sortNum;

            productFilterViewModel.filteredProducts = filteredListOfProducts;
            //TempData["productsList"] = filteredListOfProducts.ToList();
            return View(productFilterViewModel);
            
        }

    }
}