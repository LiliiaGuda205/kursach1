﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using EFProjectWEB.DataAccess;
using EFProjectWEB.Models;
using Microsoft.AspNetCore.Mvc;
using LEMARTONE.ViewModels;
using Microsoft.AspNetCore.Authorization;

namespace LEMARTONE.Controllers
{
    [Authorize(Roles = "admin")]
    public class AdminOrdersController : Controller
    {
        private readonly CategoryContext categoryContext;

        public AdminOrdersController(CategoryContext categoryContext)
        {
            this.categoryContext = categoryContext;
        }
        public ViewResult Index()
        {
            List<AdminOrdersViewModel> adminOrdersViewModel=new List<AdminOrdersViewModel>();
            List<Orders> orders = categoryContext.Orders.ToList();
            foreach (var order in orders)
            {
                adminOrdersViewModel.Add(new AdminOrdersViewModel
                {
                    order = order,
                    orderDetails =  categoryContext.OrderDetails.Where(s => s.OrderId == order.Id).ToList() ,
                    summ= (from p in categoryContext.OrderDetails.ToList()
                          where p.OrderId==order.Id
                          select p.price).Sum().ToString("0.00")

                });
            }

            return View(adminOrdersViewModel);
        }
        public ViewResult MoreInfo(int id)
        {
            List<string> pnames = new List<string>();
            Orders order = new Orders();
            List<Orders> ordrs = categoryContext.Orders.ToList();
            foreach (var or in ordrs)
            {
                if (or.Id == id)
                {
                    order = new Orders { Id = or.Id, FirstName = or.FirstName, Date = or.Date, LastName = or.LastName, PhoneNumber = or.PhoneNumber };
                }
            }


            List<OrderDetail> orderDetails = (from ord in categoryContext.OrderDetails.ToList()
                                              where ord.OrderId == id
                                              select ord).ToList();
            foreach (var orddet in orderDetails)
            {
                pnames.Add((from prod in categoryContext.Product.ToList()
                            where prod.ProductId == orddet.ProductId
                            select prod.ProductName).ToString());
            }


            string summ = (from p in categoryContext.OrderDetails.ToList()
                           where p.OrderId == id
                           select p.price).Sum().ToString("0.00");
            AdminOrdersViewModel adminOrdersViewModel = new AdminOrdersViewModel { order = order, orderDetails = orderDetails, summ = summ, ProductNames = pnames };



            return View(adminOrdersViewModel);
        }
        public RedirectToActionResult MakeOrderDone(int id)
        {
            //Finding an order
            Orders order = new Orders();
            List<Orders> ordrs = categoryContext.Orders.ToList();
            foreach (var or in ordrs)
            {
                if (or.Id == id)
                {
                    order = new Orders { Id = or.Id, FirstName = or.FirstName, /*Adresses = or.Adresses,*/ Date = or.Date, LastName = or.LastName, PhoneNumber = or.PhoneNumber };
                }
            }

            CompletedOrder completedOrder = new CompletedOrder { CompleteOrderId = order.Id, FirstName = order.FirstName, /*Adresses = order.Adresses,*/ Date = order.Date, LastName = order.LastName, PhoneNumber = order.PhoneNumber };

            //Finding an OrderDetails
            List<OrderDetail> orderDetails = (from ord in categoryContext.OrderDetails.ToList()
                                              where ord.OrderId == id
                                              select ord).ToList();
            List<CompletedOrderDetail> completedOrderDetails = new List<CompletedOrderDetail>();
            foreach(var orddet in orderDetails)
            {
                completedOrderDetails.Add(new CompletedOrderDetail { 
                    CompleteOrderId = orddet.OrderId,
                    ProductId = orddet.ProductId,
                    price = orddet.price,
                    productName = orddet.productName
                });
            }

            //Add to DataBase

            foreach(var compOrdDet in completedOrderDetails)
            {
                categoryContext.CompletedOrderDetails.Add(compOrdDet);
            }

            categoryContext.completedOrders.Add(completedOrder);

            //Delet from db
            foreach(var orddet in orderDetails)
            {
                categoryContext.OrderDetails.Remove(orddet);
            }

            foreach(var orr in categoryContext.Orders.ToList())
            {
                if (orr.Id == order.Id)
                {
                    categoryContext.Orders.Remove(orr);
                }
            }

            //Save changes
            categoryContext.SaveChanges();

            return RedirectToAction("Index");
        }
        public ViewResult DoneIndex()
        {
            List<AdminDoneOrdersViewModel> adminDoneOrdersViewModel = new List<AdminDoneOrdersViewModel>();
            List<CompletedOrder> comporders = categoryContext.completedOrders.ToList();
            foreach (var order in comporders)
            {
                adminDoneOrdersViewModel.Add(new AdminDoneOrdersViewModel
                {
                    comporder = order,
                    comporderDetails = categoryContext.CompletedOrderDetails.Where(s => s.CompleteOrderId == order.CompleteOrderId).ToList(),
                    summ = (from p in categoryContext.CompletedOrderDetails.ToList()
                            where p.CompleteOrderId == order.CompleteOrderId
                            select p.price).Sum().ToString("0.00")

                });
            }

            return View(adminDoneOrdersViewModel);
        }
        public ViewResult MoreDoneInfo(int id)
        {
            List<string> pnames = new List<string>();
            CompletedOrder comporder = new CompletedOrder();
            List<CompletedOrder> ordrs = categoryContext.completedOrders.ToList();
            foreach (var or in ordrs)
            {
                if (or.CompleteOrderId == id)
                {
                    comporder = new CompletedOrder { CompleteOrderId = or.CompleteOrderId, FirstName = or.FirstName, Adresses = or.Adresses, Date = or.Date, LastName = or.LastName, PhoneNumber = or.PhoneNumber };
                }
            }


            List<CompletedOrderDetail> orderDetails = (from ord in categoryContext.CompletedOrderDetails.ToList()
                                                       where ord.CompleteOrderId == id
                                                       select ord).ToList();
            foreach (var orddet in orderDetails)
            {
                pnames.Add((from prod in categoryContext.Product.ToList()
                            where prod.ProductId == orddet.ProductId
                            select prod.ProductName).ToString());
            }


            string summ = (from p in categoryContext.CompletedOrderDetails.ToList()
                           where p.CompleteOrderId == id
                           select p.price).Sum().ToString("0.00");
            AdminDoneOrdersViewModel adminOrdersViewModel = new AdminDoneOrdersViewModel { comporder = comporder, comporderDetails = orderDetails, summ = summ, ProductNames = pnames };



            return View(adminOrdersViewModel);
        }
    }
}