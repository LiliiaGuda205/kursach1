﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using LEMARTONE.Models;

//namespace LEMARTONE.DbContext
//{
//    public class ProductsContexts
//    {
//        public List<Product> Products = new List<Product>()
//        {
//            new Product()
//            {
//                Id = 1,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){
//                    materials=("Ткань, краска , кремний, медь"),
//                    volume=50,
//                    f_feature=("Регулирующиеся лямки"),
//                    colours=("Желтый,синий, красный")
//                },       
//                LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },

//        new Product()
//        {
//            Id = 2,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 3,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 4,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                 Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 5,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 6,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//             new Product()
//        {
//            Id = 7,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 8,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 9,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 10,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 11,
//                Name = "ПРюкзак" ,
//                Price = 100,
//                Image = "imgs/categories/BackpackTravel.png",
//                Decription = "VeryGoodGorYourMum",
//                CategoryNum = 1,
//                Chars= new Characteristics(){materials="Ткань, краска , кремний, медь",volume=50,f_feature="Регулирующиеся лямки",colours="Желтый,синий, красный"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            //new Product()
//            //{

//            //    Name = "ПРюкзак" ,
//            //    Price = 100,
//            //    Image = "imgs/categories/BackpackTravel.png",
//            //    Decription = "VeryGoodGorYourMum",
//            //    CategoryNum = 1
//            //},



//            new Product()
//        {
//            Id = 12,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 13,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 14,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 15,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 16,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 17,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 18,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,s_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 19,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,f_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 20,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,f_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 21,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,f_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 22,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,f_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 23,
//                Name = "ГРюкзак" ,
//                Price = 200,
//                Image = "imgs/categories/BackpackCity.png",
//                Decription = "VeryGoodGorYourDady",
//                CategoryNum = 2,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",volume=30,f_feature="Отделение для ноутбука",colours="Желтый,череный, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },



//            new Product()
//        {

//                Id = 24,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",f_feature="4 отделения", s_feature="Стильная форма",colours="Желтый, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 25,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",f_feature="4 отделения", s_feature="Стильная форма",colours="Желтый, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 26,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",f_feature="4 отделения", s_feature="Стильная форма",colours="Желтый, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 27,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3,
//                Chars= new Characteristics(){materials="Ткань, краска , медь",f_feature="4 отделения", s_feature="Стильная форма",colours="Желтый, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 28,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3,
//                 Chars= new Characteristics(){materials="Ткань, краска , медь",f_feature="4 отделения", s_feature="Стильная форма",colours="Желтый, серый"},
//               LongDesc=new string("It`s long description of future backpack. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure. These words will sell our production at all, be sure. It`s long description of future backpack. These words will sell our production at all, be sure.")

//            },
//            new Product()
//        {
//            Id = 29,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },
//            new Product()
//        {
//            Id = 30,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },
//            new Product()
//        {
//            Id = 31,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },
//            new Product()
//        {
//            Id = 32,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },
//            new Product()
//        {
//            Id = 33,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },
//            new Product()
//        {
//            Id = 34,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },
//            new Product()
//        {
//            Id = 35,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 3
//            },



//            new Product()
//        {
//            Id = 36,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 37,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 38,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 39,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 40,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 41,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 42,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 43,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 44,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 45,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 46,
//                 Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            },
//            new Product()
//        {
//            Id = 47,
//                Name = "Сумочка" ,
//                Price = 150,
//                Image = "imgs/categories/bag.png",
//                Decription = "VeryGoodGorYourSis",
//                CategoryNum = 4
//            }
//    };
//}
//}
