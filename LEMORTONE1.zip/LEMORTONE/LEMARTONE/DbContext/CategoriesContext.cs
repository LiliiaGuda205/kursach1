﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Threading.Tasks;
//using LEMARTONE.Models;

//namespace LEMARTONE.DbContext
//{
//    public class CategoriesContext
//    {
//        public List<Category> Categories = new List<Category>()
//        {
//            new Category()
//            {
//                Number = 1,
//                Image = "imgs/categories/BackpackTravel.png",
//                Name = "Походные рюказки"
//            },
//            new Category()
//            {
//                Number = 2,
//                Image = "imgs/categories/BackpackCity.png",
//                Name = "Городские рюказки"
//            },
//            new Category()
//            {
//                Number = 3,
//                Image = "imgs/categories/bag.png",
//                Name = "Нагрудные сумки"
//            },
//            new Category()
//            {
//                Number = 4,
//                Image = "imgs/categories/bag.png",
//                Name = "Переферия"
//            }
//        };
//    }
//}
